package com.example.test3dipanshu;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import java.sql.*;
public class HelloController implements Initializable {
    public TextField iid;
    public TextField icustomername;
    public TextField imobilenumber;
    public TextField ipizzasize;
    public TextField inumberoftoppings;
    public Label welcomeText;
    @FXML
    private TableView<orders> tableView;
    @FXML
    private TableColumn<orders,Integer > id;
    @FXML
    private TableColumn<orders, String> customername;
    @FXML
    private TableColumn<orders,Integer> mobilenumber;
    @FXML
    private TableColumn<orders,String> pizzasize;
    @FXML
    private TableColumn<orders,Integer> numberoftoppings;
    @FXML
    private TableColumn<orders,Integer> totalbill;
    ObservableList<orders> list = FXCollections.observableArrayList();

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }
    @FXML
    protected void onHelloButtonClick() {
        list.clear();
        tableView.setItems(list);
        populateTable();
    }
    public void populateTable() {
        // Establish a database connection
        String jdbcUrl = "jdbc:mysql://localhost:3306/db1_test3";
        String dbUser = "root";
        String dbPassword = "";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser,
                dbPassword)) {
            // Execute a SQL query to retrieve data from the database
            String query = "SELECT * FROM orders";
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);
            // Populate the table with data from the database
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String customername = resultSet.getString("customername");
                int mobilenumber = resultSet.getInt("mobilenumber");
                String pizzasize = resultSet.getString("pizzasize");
                int numberoftoppings = resultSet.getInt("numberoftoppings");
                int totalbill = resultSet.getInt("totalbill");
                tableView.getItems().add(new orders(id, customername, mobilenumber, pizzasize, numberoftoppings, totalbill));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void loadData(ActionEvent actionEvent) {
        String getid = iid.getText();
        String jdbcUrl = "jdbc:mysql://localhost:3306/db1_test3";
        String dbUser = "root";
        String dbPassword = "";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser,
                dbPassword)) {
            // Execute a SQL query to retrieve data from the database
            String query = "SELECT * FROM orders WHERE `id` ='"+getid+"'";
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);
            // Populate the table with data from the database
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String customername = resultSet.getString("customername");
                int mobilenumber = resultSet.getInt("mobilenumber");
                String pizzasize = resultSet.getString("pizzasize");
                int numberoftoppings = resultSet.getInt("numberoftoppings");

                icustomername.setText(customername);
                imobilenumber.setText(String.valueOf(mobilenumber));
                ipizzasize.setText(pizzasize);
                inumberoftoppings.setText(String.valueOf(numberoftoppings));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void DeleteData(ActionEvent actionEvent) {
        String getid = iid.getText();
        String jdbcUrl = "jdbc:mysql://localhost:3306/db1_test3";
        String dbUser = "root";
        String dbPassword = "";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser,
                dbPassword)) {
            // Execute a SQL query to retrieve data from the database
            String query = "DELETE FROM orders WHERE `id`= '"+getid+"'";
            Statement statement = connection.createStatement();
            statement.execute(query);
            // Populate the table with data from the database

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    public void InsertData(ActionEvent actionEvent) {
        String getid = iid.getText();
        String getcustomername = icustomername.getText();
        String getmobilenumber = imobilenumber.getText();
        String getpizzasize = ipizzasize.getText();
        String getnumberoftoppings = inumberoftoppings.getText();

        String jdbcUrl = "jdbc:mysql://localhost:3306/db1_test3";
        String dbUser = "root";
        String dbPassword = "";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser,
                dbPassword)) {
            // Execute a SQL query to retrieve data from the database
            String query = "INSERT INTO `orders`(`customername`, `mobilenumber`, `pizzasize`, `numberoftoppings`, `totalbill`) VALUES ('"+customername+"','"+mobilenumber+"','"+pizzasize+"','"+numberoftoppings+"','"+totalbill+"')";

            Statement statement = connection.createStatement();
            statement.execute(query);


            // Populate the table with data from the database

        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    public void UpdateData(ActionEvent actionEvent) {
        String getid = iid.getText();
        String getcustomername = icustomername.getText();
        String getmobilenumber = imobilenumber.getText();
        String getpizzasize = ipizzasize.getText();
        String getnumberoftoppings = inumberoftoppings.getText();


        String jdbcUrl = "jdbc:mysql://localhost:3306/db1_test3";
        String dbUser = "root";
        String dbPassword = "";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser,
                dbPassword)) {
            // Execute a SQL query to retrieve data from the database
            String query = "UPDATE `orders` SET `customername`='"+getcustomername+"',`mobilenumber`='"+getmobilenumber+"',`pizzasize`='"+getpizzasize+"',`numberoftoppings`='"+numberoftoppings+"',`totalbill`='"+totalbill+"' WHERE `id` = '"+getid+"' ";
            welcomeText.setText(query);
            Statement statement = connection.createStatement();
            statement.execute(query);
            // Populate the table with data from the database

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }



}
