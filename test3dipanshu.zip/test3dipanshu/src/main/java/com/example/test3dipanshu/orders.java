package com.example.test3dipanshu;

public class orders {

        private int id;
        private String customername;
        private int mobilenumber;
        private String pizzasize;
        private int numberoftoppings;
        private int totalbill;

        public orders(int id, String customername, int mobilenumber, String pizzasize, int numberoftoppings, int totalbill) {
            this.id = id;
            this.customername = customername;
            this.mobilenumber = mobilenumber;
            this.pizzasize = pizzasize;
            this.numberoftoppings = numberoftoppings;
            this.totalbill = totalbill;
        }
        public int getid() {
            return id;
        }
        public String getcustomername() {
            return customername;
        }
        public int getmobilenumber() {
            return mobilenumber;
        }
        public String getpizzasize() {
            return pizzasize;
        }
        public int getnumberoftoppings() {
            return numberoftoppings;
        }
        public int gettotalbill() {
            return totalbill;
        }


}
