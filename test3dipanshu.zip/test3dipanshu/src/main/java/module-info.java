module com.example.test3dipanshu {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;


    opens com.example.test3dipanshu to javafx.fxml;
    exports com.example.test3dipanshu;
}